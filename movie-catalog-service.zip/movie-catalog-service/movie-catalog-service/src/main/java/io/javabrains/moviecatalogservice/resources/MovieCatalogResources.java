package io.javabrains.moviecatalogservice.resources;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import io.javabrains.moviecatalogservice.models.CatalogItems;
import io.javabrains.moviecatalogservice.models.Movie;
import io.javabrains.moviecatalogservice.models.Rating;
import io.javabrains.moviecatalogservice.models.UserRating;

@RestController
@RequestMapping("/catalog")
public class MovieCatalogResources {

	@RequestMapping("/{userId}")
	public List<CatalogItems> getCatalog(@PathVariable String userId) {
		RestTemplate restTemplate = new RestTemplate();

		// get all rated movie Id's
		//List<Rating> rating = Arrays.asList(new Rating("1234", 4), new Rating("5678", 5));
		UserRating ratings = restTemplate.getForObject("http://localhost:8083/ratingsdata/"+userId, UserRating.class);
		
		return ratings.getRatings().stream().map(r -> {

			Movie movie = restTemplate.getForObject("http://localhost:8082/movies/" + r.getMovieId(), Movie.class);
			return new CatalogItems(movie.getName(), "test", r.getRating());
		}).collect(Collectors.toList());

		// For each movie ID, call movie info service and get details

		// Put them all together
	}
	
	

}
